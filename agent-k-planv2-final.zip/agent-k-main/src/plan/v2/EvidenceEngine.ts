/**
 * EvidenceEngine — problem #9 from the original review, and the piece every
 * reviewer in this thread agreed was the most important idea to keep:
 *
 * Don't tell the agent "finish Task 1 before touching Task 2" — it won't
 * reliably obey that, and enforcing it server-side just means false
 * failures when the agent's actual (reasonable) behavior doesn't match a
 * rigid step order. Instead, observe what tools actually did and derive
 * task status from that evidence.
 *
 * Correlation is intentionally simple and file/command-path based:
 *  - a read-ish tool touching one of a task's files -> in_progress
 *  - an edit/write tool touching one of a task's files -> satisfied
 *  - a terminal/test tool whose command matches one of the task's
 *    verification strings, and which succeeded -> verified
 *  - a terminal/test tool matching a verification string that failed -> failed
 *
 * This is a heuristic correlation layer, not a guarantee — it's meant to
 * replace *enforced* step order with *observed* progress, which is strictly
 * better even when the correlation itself is approximate.
 */
import type { PlanTask, TaskStatus } from './schema';
import type { ToolEvidence } from './PlanEvent';

export interface ObservedToolCall {
  toolName: string;
  /** File path for read/edit/write tools. */
  filePath?: string;
  /** Shell command for terminal/test tools. */
  command?: string;
  success: boolean;
  timestamp: number;
}

const READ_TOOLS = new Set(['read_file', 'read_files', 'grep', 'glob', 'file_search', 'codebase_search', 'list_dir', 'lsp_definition', 'lsp_references']);
const WRITE_TOOLS = new Set(['edit_file', 'write_file', 'delete_file']);
const RUN_TOOLS = new Set(['run_terminal_cmd']);

export interface TaskStatusUpdate {
  taskId: string;
  to: TaskStatus;
  evidence: ToolEvidence;
}

/**
 * Given one observed tool call and the set of tasks in the current plan,
 * return zero or more task-status updates implied by that evidence.
 * A single tool call can affect multiple tasks if they share a file.
 */
export function deriveTaskUpdates(
  call: ObservedToolCall,
  tasks: PlanTask[]
): TaskStatusUpdate[] {
  const updates: TaskStatusUpdate[] = [];
  const evidence: ToolEvidence = {
    toolName: call.toolName,
    target: call.filePath ?? call.command,
    success: call.success,
    timestamp: call.timestamp
  };

  if (call.filePath && (READ_TOOLS.has(call.toolName) || WRITE_TOOLS.has(call.toolName))) {
    const isWrite = WRITE_TOOLS.has(call.toolName);
    for (const task of tasks) {
      const touches = task.files.some((f) => {
        if (!pathsMatch(f.path, call.filePath!)) return false;
        // Reads are valid evidence for every file intent. Writes are only
        // evidence for files the plan explicitly allows to be created/modified.
        return !isWrite || f.intent === 'modify' || f.intent === 'create';
      });
      if (!touches) continue;
      updates.push({
        taskId: task.id,
        to: isWrite ? (call.success ? 'satisfied' : 'failed') : 'in_progress',
        evidence
      });
    }
  }

  if (call.command && RUN_TOOLS.has(call.toolName)) {
    for (const task of tasks) {
      const matchesVerification = task.verification.some((v) => commandsMatch(v, call.command!));
      if (!matchesVerification) continue;
      updates.push({
        taskId: task.id,
        to: call.success ? 'verified' : 'failed',
        evidence
      });
    }
  }

  return updates;
}

function pathsMatch(taskPath: string, toolPath: string): boolean {
  const norm = (p: string) => p
    .replace(/\\/g, '/')
    .replace(/^\.\//, '')
    .replace(/^\/+/, '')
    .replace(/\/+$/, '')
    .split('/')
    .filter(Boolean)
    .join('/');
  const a = norm(taskPath);
  const b = norm(toolPath);
  if (!a || !b) return false;
  // Exact relative path or an absolute workspace path ending at that exact
  // relative path. Never match a bare basename (foo.ts) against unrelated
  // nested files with the same name.
  return a === b || b.endsWith(`/${a}`);
}

/** Match the declared verification command or a safe suffix of it. This
 * avoids the old substring behavior where `npm test-old` could satisfy
 * `npm test`. A common `cd ... && <command>` wrapper is also accepted. */
function commandsMatch(verification: string, command: string): boolean {
  const v = verification.trim().toLowerCase();
  const c = command.trim().toLowerCase();
  if (!v || !c) return false;
  if (c === v || c.startsWith(`${v} `) || c.startsWith(`${v}\n`)) return true;
  const shell = c.match(/^(?:cd\s+[^&]+&&\s*)+(.+)$/);
  return Boolean(shell && (shell[1] === v || shell[1].startsWith(`${v} `)));
}
