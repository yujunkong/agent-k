/**
 * PlanSession — the single object both the Plan UI and Agent execution
 * read from. This is the fix for problem #1 from the original review:
 * "Plan exists as both a conversation and a separate workflow, and they
 * have to be kept in sync by hand."
 *
 * Every state change happens through `recordEvent()`. Nothing mutates
 * `state` directly from outside — that's what made the old Chat/Plan split
 * possible to fall out of sync in the first place.
 */
import type { PlanDocument, PlanTask, TaskStatus } from './schema';
import type { PlanEvent } from './PlanEvent';
import { assertLegalPhaseTransition } from './PlanPhaseTransitions';

export type PlanPhase =
  | 'idle'
  | 'research'
  | 'planning'
  | 'review'
  | 'executing'
  | 'completed'
  | 'failed';

export interface PlanSessionState {
  id: string;
  phase: PlanPhase;
  goal: string;
  researchFindings: string;
  plan: PlanDocument | null;
  /** taskId -> status, kept separately from plan.tasks so PlanDocument stays
   *  an immutable record of "what was approved" while execution progresses. */
  taskStatus: Record<string, TaskStatus>;
  /** Merge note: subset approval, borrowed from the other implementation's
   *  `approvedTaskIds`. Undefined/empty = "all tasks approved" (the
   *  original all-or-nothing behavior); non-empty = only these tasks are
   *  in scope for execution / isAllTasksVerified(). */
  approvedTaskIds: string[];
  rejectionFeedback: string[];
  events: PlanEvent[];
}

const TERMINAL_STATUSES: TaskStatus[] = ['verified'];

export class PlanSession {
  private state: PlanSessionState;
  private listeners: Array<(event: PlanEvent) => void> = [];

  constructor(id: string) {
    this.state = {
      id,
      phase: 'idle',
      goal: '',
      researchFindings: '',
      plan: null,
      taskStatus: {},
      approvedTaskIds: [],
      rejectionFeedback: [],
      events: []
    };
  }

  getState(): Readonly<PlanSessionState> {
    return this.state;
  }

  getPhase(): PlanPhase {
    return this.state.phase;
  }

  /** Explicitly discard the current planning session. This is different from
   * plan.failed: the user intentionally abandoned the plan and a future
   * Plan run must start from a clean state. */
  reset(): void {
    this.state = {
      id: this.state.id,
      phase: 'idle',
      goal: '',
      researchFindings: '',
      plan: null,
      taskStatus: {},
      approvedTaskIds: [],
      rejectionFeedback: [],
      events: []
    };
  }

  getPlan(): PlanDocument | null {
    return this.state.plan;
  }

  getTaskStatus(taskId: string): TaskStatus | undefined {
    return this.state.taskStatus[taskId];
  }

  /** All events recorded so far, in order. Useful for debugging /
   *  reconstructing "what happened" without scraping chat messages. */
  getEvents(): readonly PlanEvent[] {
    return this.state.events;
  }

  /** Merge note: pub/sub borrowed from the other implementation's
   *  PlanSessionStore.onEvent — lets ChatApp/UI react to state changes
   *  instead of polling getState() after every call. */
  onEvent(listener: (event: PlanEvent) => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private emit(event: PlanEvent): void {
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch {
        // a listener throwing must never break session state changes
      }
    }
  }

  /** Which tasks are actually in scope for execution / completion.
   *  Empty approvedTaskIds means "all tasks" (default, all-or-nothing). */
  private scopedTaskIds(): string[] {
    if (this.state.approvedTaskIds.length > 0) return this.state.approvedTaskIds;
    return this.state.plan?.tasks.map((t) => t.id) ?? [];
  }

  /**
   * The only way state changes. Each event type has a narrow, explicit
   * effect — no heuristic inference about what a message "probably means".
   *
   * Merge note: phase changes are validated against PLAN_PHASE_TRANSITIONS
   * before being applied (throws IllegalPhaseTransitionError on an illegal
   * jump) — borrowed from the other implementation's PlanTransitions.ts.
   * Task-status changes (task.status.changed) are NOT subject to this
   * guard — see PlanPhaseTransitions.ts for why.
   */
  recordEvent(event: PlanEvent): void {
    const nextPhase = this.computeNextPhase(event);
    if (nextPhase && nextPhase !== this.state.phase) {
      assertLegalPhaseTransition(this.state.phase, nextPhase);
    }

    this.state.events.push(event);

    switch (event.type) {
      case 'plan.started':
        this.state.phase = 'research';
        this.state.goal = event.goal;
        this.state.researchFindings = '';
        this.state.plan = null;
        this.state.taskStatus = {};
        this.state.approvedTaskIds = [];
        this.state.rejectionFeedback = [];
        break;

      case 'research.completed':
        this.state.researchFindings = event.findings;
        this.state.phase = 'planning';
        break;

      case 'plan.generation.attempt':
        this.state.phase = 'planning';
        break;

      case 'plan.generation.failed':
        // Stay in 'planning' — the caller is expected to retry or give up
        // (see PlanV2Generator's maxAttempts). We don't move to 'failed'
        // here because a retry is still in flight.
        break;

      case 'plan.generated':
        this.state.plan = event.plan;
        this.state.taskStatus = Object.fromEntries(
          event.plan.tasks.map((t) => [t.id, 'pending' as TaskStatus])
        );
        this.state.approvedTaskIds = [];
        this.state.phase = 'review';
        break;

      case 'plan.review.opened':
        this.state.phase = 'review';
        break;

      case 'plan.approved':
        this.state.approvedTaskIds = event.taskIds && event.taskIds.length > 0
          ? this.expandApprovalScope(event.taskIds)
          : [];
        this.state.phase = 'executing';
        break;

      case 'plan.rejected':
        this.state.rejectionFeedback.push(event.feedback);
        this.state.phase = 'planning';
        break;

      case 'task.status.changed':
        this.applyTaskTransition(event.taskId, event.to);
        break;

      case 'plan.completed':
        this.state.phase = 'completed';
        break;

      case 'plan.failed':
        this.state.phase = 'failed';
        break;
    }

    this.emit(event);
  }

  /** Pure mapping from event -> the phase it would move to, if any.
   *  Returns undefined for events that don't change phase (e.g.
   *  task.status.changed) so recordEvent skips the transition guard. */
  private computeNextPhase(event: PlanEvent): PlanPhase | undefined {
    switch (event.type) {
      case 'plan.started':
        return 'research';
      case 'research.completed':
      case 'plan.generation.attempt':
        return 'planning';
      case 'plan.generated':
      case 'plan.review.opened':
        return 'review';
      case 'plan.approved':
        return 'executing';
      case 'plan.rejected':
        return 'planning';
      case 'plan.completed':
        return 'completed';
      case 'plan.failed':
        return 'failed';
      default:
        return undefined;
    }
  }

  /**
   * Rejection feedback rendered as prompt text for the next planning
   * attempt — first-class input, not lost context (problem #7 from the
   * original review).
   */
  getRejectionContextPrompt(): string {
    if (this.state.rejectionFeedback.length === 0) return '';
    const latest = this.state.rejectionFeedback[this.state.rejectionFeedback.length - 1];
    return [
      'The previous plan was rejected by the user with this feedback:',
      `"${latest}"`,
      '',
      'Address this feedback explicitly in the new plan.'
    ].join('\n');
  }

  /** Task-level summary for a "current task" execution context, avoiding
   *  dumping the entire plan into the agent's context on every turn. */
  getTaskContext(taskId: string): { task: PlanTask; status: TaskStatus } | null {
    const task = this.state.plan?.tasks.find((t) => t.id === taskId);
    if (!task) return null;
    return { task, status: this.state.taskStatus[taskId] || 'pending' };
  }

  /** Next task with unmet dependencies excluded — a suggestion, not an
   *  enforced order (Evidence Engine still governs actual status changes).
   *  Only considers tasks in the approved scope (see scopedTaskIds()). */
  getNextSuggestedTask(): PlanTask | null {
    if (!this.state.plan) return null;
    const scope = new Set(this.scopedTaskIds());
    for (const task of this.state.plan.tasks) {
      if (!scope.has(task.id)) continue;
      const status = this.state.taskStatus[task.id] || 'pending';
      if (TERMINAL_STATUSES.includes(status) || status === 'blocked') continue;
      const depsVerified = task.dependencies.every(
        (dep) => this.state.taskStatus[dep] === 'verified'
      );
      if (depsVerified) return { ...task, status };
    }
    return null;
  }

  /** Partial approval cannot deadlock on an unapproved dependency. When
   * a task is approved, its transitive dependencies are automatically added
   * to the execution scope as prerequisites. */
  private expandApprovalScope(taskIds: string[]): string[] {
    const plan = this.state.plan;
    if (!plan) return [];
    const byId = new Map(plan.tasks.map((task) => [task.id, task]));
    const scope = new Set<string>();
    const visit = (id: string) => {
      if (scope.has(id)) return;
      const task = byId.get(id);
      if (!task) return;
      scope.add(id);
      task.dependencies.forEach(visit);
    };
    taskIds.forEach(visit);
    return plan.tasks.map((task) => task.id).filter((id) => scope.has(id));
  }

  /** True once every task in the approved scope is verified. Merge note:
   *  the scope narrows to approvedTaskIds when a partial approval was
   *  recorded (plan.approved with taskIds), so an out-of-scope task being
   *  unfinished doesn't block "done" for the tasks that were approved. */
  isAllTasksVerified(): boolean {
    if (!this.state.plan || this.state.plan.tasks.length === 0) return false;
    const scope = this.scopedTaskIds();
    if (scope.length === 0) return false;
    return scope.every((id) => this.state.taskStatus[id] === 'verified');
  }

  /**
   * Deliberately permissive: any status can move to any other status.
   * This is the direct consequence of the "evidence, not enforced order"
   * design (problem #9 from the original review) — a test passing is proof
   * of 'verified' regardless of what status bookkeeping said before, and a
   * tool touching a file is proof of activity regardless of plan order.
   * Rejecting or reinterpreting evidence here would just reintroduce the
   * same "runtime state disagrees with what actually happened" bug this
   * whole module exists to fix.
   */
  private applyTaskTransition(taskId: string, to: TaskStatus): void {
    const from = this.state.taskStatus[taskId];
    if (from === undefined) {
      // Evidence referenced a task not in the plan — ignore rather than throw.
      // Runtime evidence is inherently noisy (see EvidenceEngine.ts); a
      // malformed correlation should never crash the session.
      return;
    }
    this.state.taskStatus[taskId] = to;
  }

  /** Serialize for persistence (PlanStorage) / hydration (tab switch). */
  toJSON(): PlanSessionState {
    return JSON.parse(JSON.stringify(this.state));
  }

  static fromJSON(state: PlanSessionState): PlanSession {
    const session = new PlanSession(state.id);
    session.state = state;
    return session;
  }
}
